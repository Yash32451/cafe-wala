# Copper & Oak Café

A responsive, seven-page static café website, ready to deploy to Vercel.

## Deploy

1. Extract the ZIP.
2. Import the extracted folder into a GitHub repository, or run `vercel` from this folder.
3. In Vercel, choose **Other** as the framework preset. No build command is needed; set the output directory to `.`.

The site is static HTML, CSS, and JavaScript. The contact, login, and registration forms are front-end demos and display a confirmation; connect them to a backend or form service before using them for real submissions or accounts. The homepage photo and fonts load from Unsplash and Google Fonts.
